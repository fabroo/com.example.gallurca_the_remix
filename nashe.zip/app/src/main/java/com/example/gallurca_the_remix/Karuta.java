package com.example.gallurca_the_remix;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;

import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;
import java.util.Map;

public class Karuta extends AppCompatActivity {
    private FirebaseFirestore db;
    private FirebaseAuth auth;
    private FirebaseUser user;
    private boolean caught;

    public int getRandomNumber(int min, int max) {
        return (int) ((Math.random() * (max - min)) + min);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState){
        caught = true;
        db = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_karuta);
        Button roll = findViewById(R.id.roll_button);
        roll.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                if(caught){
                    int[] images = {R.drawable.carta_medio_picante, R.drawable.carta_pete, R.drawable.carta_picante};
                    caught = false;

                    ImageView[] views = {findViewById(R.id.foto_1), findViewById(R.id.foto_2)};
                    for(ImageView v : views){
                        int random = getRandomNumber(0,views.length);
                        v.setImageResource(images[random]);
                        v.setOnClickListener( new View.OnClickListener(){
                            @Override
                            public void onClick(View view){

                                if(!caught) {
                                    caught = true;
                                    String picname = getResources().getResourceName(images[random]).split("/")[1];
                                    picname = picname.substring(0, 1).toUpperCase() + picname.substring(1);
                                    Log.d("picname", picname);
                                    Log.d("Imagen id", view.getResources().getResourceName(view.getId()));
                                    int quality = getRandomNumber(1,4);
                                    Map<String, Object> data = new HashMap<String, Object>();
                                    data.put("nombre", picname);
                                    data.put("imageid", images[random]);
                                    data.put("quality", quality);
                                    db.collection("users").document(user.getUid()).collection("cookies").add(data);
                                    Toast.makeText(Karuta.this, "Agarraste " + picname + "! Calidad: " + Integer.toString(quality) +"★", Toast.LENGTH_LONG).show();

                                }
                            }
                        });
                    }
                }
            }
        });
    }


}
